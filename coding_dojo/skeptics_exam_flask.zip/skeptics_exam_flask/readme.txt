model: ex.user.py  
view: templates/flask routes ex. server.py 
controller: mysqlconnection.py